output "id" {
  description = "The ID of the LAN."
  value       = ionoscloud_lan.this.id
}
