resource "ionoscloud_lan" "this" {
  datacenter_id   = var.datacenter_id
  name            = var.name
  public          = var.public
  pcc             = var.pcc
  ipv4_cidr_block = var.ipv4_cidr_block
  ipv6_cidr_block = var.ipv6_cidr_block
  location        = var.location

  timeouts {
    create  = var.timeouts.create
    update  = var.timeouts.update
    delete  = var.timeouts.delete
    default = var.timeouts.default
  }
}
