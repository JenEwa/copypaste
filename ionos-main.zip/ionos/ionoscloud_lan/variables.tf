variable "datacenter_id" {
  description = "ID of the Virtual Data Center the LAN belongs to."
  type        = string
}

variable "name" {
  description = "The name of the LAN."
  type        = string
  default     = null
}

variable "public" {
  description = "Whether the LAN faces the public internet (true) or not (false)."
  type        = bool
  default     = null
}

variable "pcc" {
  description = "ID of an ionoscloud_private_crossconnect to attach the LAN to."
  type        = string
  default     = null
}

variable "ipv4_cidr_block" {
  description = "IPv4 CIDR block of a private LAN, e.g. 10.5.0.0/24: RFC 1918, prefix /23 to /28, aligned. Omitted, a /23 from 10.0.0.0/8 is assigned."
  type        = string
  default     = null
}

variable "ipv6_cidr_block" {
  description = "The /64 IPv6 CIDR block of the LAN. \"AUTO\" enables IPv6 and assigns one."
  type        = string
  default     = null
}

variable "location" {
  description = "Location of the LAN, e.g. de/fra. Not in the registry docs, but part of the provider schema."
  type        = string
  default     = null
}

variable "timeouts" {
  description = "Operation timeouts, e.g. { create = \"60m\" }. Not in the registry docs, but part of the provider schema."
  type = object({
    create  = optional(string)
    update  = optional(string)
    delete  = optional(string)
    default = optional(string)
  })
  default = {}
}

variable "keeper_record_uid" {
  description = "UID of the Keeper login record whose password is the IONOS API token."
  type        = string
}
