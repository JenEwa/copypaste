# Ephemeral: the token never reaches the plan or the state.
ephemeral "secretsmanager_login" "ionos_token" {
  path = var.keeper_record_uid
}
