output "id" {
  description = "The UUID of the data center."
  value       = ionoscloud_datacenter.this.id
}
