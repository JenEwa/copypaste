resource "ionoscloud_datacenter" "this" {
  name                = var.name
  location            = var.location
  description         = var.description
  sec_auth_protection = var.sec_auth_protection

  timeouts {
    create  = var.timeouts.create
    update  = var.timeouts.update
    delete  = var.timeouts.delete
    default = var.timeouts.default
  }
}
