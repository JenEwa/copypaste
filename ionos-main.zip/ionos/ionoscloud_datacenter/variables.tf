variable "name" {
  description = "The name of the Virtual Data Center."
  type        = string
}

variable "location" {
  description = "The regional location of the data center, e.g. de/fra, de/txl, gb/lhr. Changing it forces a new resource."
  type        = string
}

variable "description" {
  description = "A description for the data center."
  type        = string
  default     = null
}

variable "sec_auth_protection" {
  description = "Whether the data center requires extra protection, such as two-factor authentication."
  type        = bool
  default     = null
}

variable "timeouts" {
  description = "Operation timeouts, e.g. { create = \"60m\" }. Not in the registry docs, but part of the provider schema."
  type = object({
    create  = optional(string)
    update  = optional(string)
    delete  = optional(string)
    default = optional(string)
  })
  default = {}
}

variable "keeper_record_uid" {
  description = "UID of the Keeper login record whose password is the IONOS API token."
  type        = string
}
