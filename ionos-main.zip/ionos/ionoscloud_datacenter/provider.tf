# Credential comes from the KEEPER_CREDENTIAL environment variable.
provider "secretsmanager" {}

provider "ionoscloud" {
  token = ephemeral.secretsmanager_login.ionos_token.password
}
