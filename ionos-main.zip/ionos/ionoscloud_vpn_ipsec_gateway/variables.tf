variable "name" {
  description = "The name of the IPSec gateway."
  type        = string
}

variable "location" {
  description = "The location of the gateway, e.g. de/fra."
  type        = string
  default     = null
}

variable "gateway_ip" {
  description = "Public IP of the gateway, e.g. module.ipblock.ips[0]. Must be in the same location as the connections."
  type        = string
}

variable "description" {
  description = "A description of the gateway."
  type        = string
  default     = null
}

variable "version_ike" {
  description = "IKE version permitted for VPN tunnels. Only IKEv2 is allowed; the API defaults to it."
  type        = string
  default     = null
}

variable "tier" {
  description = "Performance tier: STANDARD, STANDARD_HA, ENHANCED, ENHANCED_HA, PREMIUM or PREMIUM_HA."
  type        = string
  default     = null
}

variable "connections" {
  description = "LAN connections of the gateway, all in the same datacenter. ipv4_cidr is the gateway's private address inside the LAN subnet."
  type = list(object({
    datacenter_id = string
    lan_id        = string
    ipv4_cidr     = string
    ipv6_cidr     = optional(string)
  }))
}

variable "maintenance_window" {
  description = "Weekly four-hour maintenance window, e.g. { day_of_the_week = \"Monday\", time = \"09:00:00\" } (UTC). Null lets the API pick one."
  type = object({
    day_of_the_week = string
    time            = string
  })
  default = null
}

variable "timeouts" {
  description = "Operation timeouts, e.g. { create = \"60m\" }. Not in the registry docs, but part of the provider schema."
  type = object({
    create  = optional(string)
    update  = optional(string)
    delete  = optional(string)
    default = optional(string)
  })
  default = {}
}

variable "keeper_record_uid" {
  description = "UID of the Keeper login record whose password is the IONOS API token."
  type        = string
}
