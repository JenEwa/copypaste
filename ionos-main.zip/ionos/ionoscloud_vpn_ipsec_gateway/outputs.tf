output "id" {
  description = "The ID of the IPSec gateway."
  value       = ionoscloud_vpn_ipsec_gateway.this.id
}
