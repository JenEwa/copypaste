resource "ionoscloud_vpn_ipsec_gateway" "this" {
  name        = var.name
  location    = var.location
  gateway_ip  = var.gateway_ip
  description = var.description
  version     = var.version_ike
  tier        = var.tier

  dynamic "connections" {
    for_each = var.connections
    content {
      datacenter_id = connections.value.datacenter_id
      lan_id        = connections.value.lan_id
      ipv4_cidr     = connections.value.ipv4_cidr
      ipv6_cidr     = connections.value.ipv6_cidr
    }
  }

  dynamic "maintenance_window" {
    for_each = var.maintenance_window[*]
    content {
      day_of_the_week = maintenance_window.value.day_of_the_week
      time            = maintenance_window.value.time
    }
  }

  timeouts {
    create  = var.timeouts.create
    update  = var.timeouts.update
    delete  = var.timeouts.delete
    default = var.timeouts.default
  }
}
