resource "ionoscloud_ipblock" "this" {
  name     = var.name
  location = var.location
  size     = var.size

  timeouts {
    create  = var.timeouts.create
    update  = var.timeouts.update
    delete  = var.timeouts.delete
    default = var.timeouts.default
  }
}
