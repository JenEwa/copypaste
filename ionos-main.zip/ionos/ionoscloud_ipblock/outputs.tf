output "id" {
  description = "The UUID of the IP block."
  value       = ionoscloud_ipblock.this.id
}

output "ips" {
  description = "The reserved IP addresses."
  value       = ionoscloud_ipblock.this.ips
}
