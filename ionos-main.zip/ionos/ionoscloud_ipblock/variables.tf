variable "name" {
  description = "The name of the IP block."
  type        = string
  default     = null
}

variable "location" {
  description = "The regional location of the IP block, e.g. de/fra. Must match the datacenter it is used in."
  type        = string
}

variable "size" {
  description = "The number of IP addresses to reserve."
  type        = number
}

variable "timeouts" {
  description = "Operation timeouts, e.g. { create = \"60m\" }. Not in the registry docs, but part of the provider schema."
  type = object({
    create  = optional(string)
    update  = optional(string)
    delete  = optional(string)
    default = optional(string)
  })
  default = {}
}

variable "keeper_record_uid" {
  description = "UID of the Keeper login record whose password is the IONOS API token."
  type        = string
}
